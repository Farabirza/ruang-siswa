@extends('layouts.master')

@push('css-styles')
<style>
</style>
@endpush

@section('content')

@endsection

@push('scripts')
<script type="text/javascript">
</script>
@endpush