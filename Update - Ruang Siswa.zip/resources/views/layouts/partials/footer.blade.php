<section id="section-footer">
    <div class="container">
        <div class="row justify-content-center ptb-20">
            <div class="col-md-10 text-center">
                <p>© Copyright <a href="#" target="_blank">irzafarabi.com</a></p>
            </div>
        </div>
    </div>
</section>