

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<style>
table { font-size: .8em; }
td { vertical-align: middle; }
.alert { font-size: .8em; padding: 10px; }

.steam-item-cover > img { height: 100%; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div class="container pt-3 my-3">
        <div class="row">
            <div class="col-md-12 text-center">
                <h1 class="display-5 content-title">Steam Projects</h1>
                <div class="flex-center">
                    <hr class="w-25 border border-1 border-primary">
                </div>
            </div>
        </div>
        <!-- steam projects start -->
        <div class="row py-4 mb-4">
            <?php if(Auth::check() && Auth::user()->profile->role == 'student'): ?>
            <div class="col-md-12 bg-light border rounded p-4 mb-3 d-flex flex-wrap">
                <div class="col-md-12 ps-2">
                    <h3 class="text-primary flex-between gap-3">
                        <span class="flex-start gap-2"><i class="bx bx-file"></i>My Projects</span>
                        <hr class="col">
                        <a href="/steamProject/create"><i class="bx bx-plus-circle popper" title="New project"></i></a>
                    </h3>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = Auth::user()->steamMember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-3 p-2">
                    <div class="rounded border bg-white">
                        <div class="p-3">
                            <h5 class="text-muted fs-7 mb-1"><?php echo e(date('j F Y', strtotime($item->steamProject->created_at))); ?></h5>
                            <p class="text-primary fs-12 mb-1">
                                <a href="/steamProject/<?php echo e($item->steamProject->id); ?>"><?php echo e($item->steamProject->title); ?></a>
                            </p>
                            <p class="fs-8 m-0"><?php echo e($item->steamProject->steamCategory->name); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="fst-italic mt-3 fs-9">You are not a part of any project</p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php $__empty_1 = true; $__currentLoopData = $steamProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 p-2">
                <a href="/steamProject/<?php echo e($item->id); ?>">
                <div class="rounded border hover-shadow bg-white">
                    <div class="rounded-top" style="height:240px">
                        <div class="d-flex justify-content-center overflow-hidden" style="height:240px; background:whitesmoke">
                            <?php if($item->image): ?>
                            <img src="<?php echo e(asset('img/steam/'.$item->image)); ?>">
                            <?php else: ?>
                            <img src="<?php echo e(asset('img/materials/noimage.jpg')); ?>">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="p-3">
                        <h5 class="text-end text-muted fs-7 mb-1"><?php echo e(date('j F Y', strtotime($item->created_at))); ?></h5>
                        <p class="text-primary fs-12 mb-1"><?php echo e($item->title); ?></p>
                        <p class="fs-8 mb-2"><?php echo e($item->steamCategory->name); ?></p>
                        <p class="fs-8 text-secondary mb-4">
                            <?php for($i = 0; $i < count($item->steamMember); $i++): ?>
                            <?php if($i < count($item->steamMember)-1): ?>
                            <span><?php echo e($item->steamMember[$i]->user->profile->full_name); ?>,</span>
                            <?php else: ?>
                            <span><?php echo e($item->steamMember[$i]->user->profile->full_name); ?></span>
                            <?php endif; ?>
                            <?php endfor; ?>
                        </p>
                        <div class="flex-start flex-wrap gap-4 fs-9 text-secondary">
                            <div class="flex-start gap-2"><i class="bx bx-message"></i><?php echo e(count($item->comment)); ?></div>
                        </div>
                    </div>
                </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="fs-9 text-muted text-center">No project has been made yet</p>
            <?php endif; ?>
        </div>
        <!-- steam projects end -->

        <!-- steam log books start -->
        <div class="row rounded shadow bg-white p-4 mb-5">
            <h3 class="display-5 fs-18 text-primary mb-2">STEAM Log Book</h3>
            <div class="table-container">
                <table id="table-steamLogBook" class="table table-striped">
                    <thead>
                        <th>Date</th>
                        <th>Log title</th>
                        <th>Project title</th>
                        <th>Project category</th>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $steamLogBooks->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(date('j F Y', strtotime($item->created_at))); ?></td>
                            <td><a href="/steamLogBook/<?php echo e($item->id); ?>" class="hover-primary"><?php echo e($item->title); ?></a></td>
                            <td><a href="/steamProject/<?php echo e($item->steamProject->id); ?>" class="hover-primary"><?php echo e($item->steamProject->title); ?></a></td>
                            <td><?php echo e($item->steamProject->steamCategory->name); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-muted" colspan="4">Empty</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- steam log books end -->

        <!-- steam categories start -->
        <div class="row rounded shadow bg-white pb-3 mb-4">
            <div class="bg-primary p-4 rounded-top mb-4 text-white flex-between gap-3">
                <h3 class="m-0 fs-18 fw-500">STEAM Project Categories</h3>
                <?php if(Auth::check() && Auth::user()->profile->role != 'student'): ?>
                <i class="bx bx-plus-circle fs-18" role="button" onclick="modalSteamCategory('post')"></i>
                <?php endif; ?>
            </div>
            <?php $i = 1; ?>
            <?php $__empty_1 = true; $__currentLoopData = $steamCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <input type="hidden" name="steamCategory_id" id="steamCategory_id-<?php echo e($i); ?>" value="<?php echo e($item->id); ?>">
            <div id="steamCategory-item-<?php echo e($i); ?>" class="col-md-12 d-flex align-items-center flex-remove-md gap-3 py-3 mb-3">
                <div class="col-md-6 px-4 text-center">
                    <?php if($item->image): ?>
                    <img id="steamCategory-image-<?php echo e($i); ?>" src="<?php echo e(asset('img/steam/categories/'.$item->image)); ?>" class="rounded border img-fluid" style="max-height:320px">
                    <?php else: ?>
                    <img id="steamCategory-image-<?php echo e($i); ?>" src="<?php echo e(asset('img/materials/noimage.jpg')); ?>" class="rounded border img-fluid" style="max-height:320px">
                    <?php endif; ?>
                </div>
                <div class="col-md-6 px-4">
                    <p class="flex-between gap-3">
                        <span id="steamCategory-name-<?php echo e($i); ?>" class="fw-500 fs-16 text-primary"><?php echo e($item->name); ?></span>
                        <?php if(Auth::check() && Auth::user()->profile->role != 'student'): ?>
                        <i class="bx bx-edit-alt text-muted hover-primary" role="button" onclick="modalSteamCategory('update', '<?php echo e($i); ?>')"></i>
                        <?php endif; ?>
                    </p>
                    <p id="steamCategory-description-<?php echo e($i); ?>" class="fs-9" style="color:#404040"><?php echo e($item->description); ?></p>
                    <div class="flex-start gap-3">
                        <span class="fs-9">Projects : <?php echo e(count($item->steamProject)); ?></span>
                    </div>
                </div>
            </div>
            <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="fst-italic">No project category has been made yet</p>
            <?php endif; ?>
        </div>
        <!-- steam categories end -->
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php if(Auth::check() && Auth::user()->profile->role != 'student'): ?>
<?php echo $__env->make('layouts.partials.modal_steamCategory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script type="text/javascript">
// glightbox
const lightbox = GLightbox({
    touchNavigation: true,
    loop: true,
    autoplayVideos: true
});
$(document).ready(function() {
    new DataTable('#table-steamLogBook', {
        pageLength: 50,
        fixedColumns: true,
        ordering: true,
        searching: true,
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ruang Siswa\resources\views/steam/index.blade.php ENDPATH**/ ?>