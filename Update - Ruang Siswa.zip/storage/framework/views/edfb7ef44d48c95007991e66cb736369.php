

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<style>
table { font-size: .8em; }
.alert { font-size: .9em; padding: 10px; margin-bottom: 0; }

.steam-controller {
    right: 20px;
    top: 20px;
    position: absolute;
} .steam-controller > a { border: 1px solid #fff; transition: .2s ease-in-out; }

.steam-cover {
    position: relative;
    <?php if($steam->image): ?>
    background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url("<?php echo e(asset('img/steam/'.$steam->image)); ?>") top center;
    <?php else: ?>
    background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url("<?php echo e(asset('img/materials/noimage.jpg')); ?>") top center;
    <?php endif; ?>
    background-size: cover;
    background-position: fixed;
    min-height: 280px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 80px 20px;
}

.comment-content {
  background-color: #f1f1f1;
  color: #444;
  width: 100%;
  padding: 10px;
  border-radius: 4px;
  margin: 5px 0 0 10px;
  position: relative;
}
.comment-content::after, .comment-content::before {
  border: solid transparent;
  border-right-color: #f1f1f1;
  content: " ";
  height: 0;
  pointer-events: none;
  position: absolute;
  right: 100%;
  top: 15px;
  width: 0;
}
.comment-content::after {
  border-width: 5px;
  margin-top: -5px;
}
.comment-content::before {
  border-width: 6px;
  margin-top: -6px;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section>
    <div class="container pt-3 my-3">
        <!-- breadcrumb start -->
        <div class="col-md-12">
            <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="/steamProject">STEAM Project</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($steam->title); ?></li>
                </ol>
            </nav>
        </div>
        <!-- breadcrumb end -->
    </div>

    <!-- container start -->
    <div class="container mb-4">
        <div class="row bg-white rounded shadow">
            <div class="steam-cover rounded-top">
                <?php if(Auth::check() && (Auth::user()->profile->role != 'student' || $isMember == true)): ?>
                <div class="steam-controller flex-end gap-3">
                    <a href="/steamProject/<?php echo e($steam->id); ?>/delete" class="btn-outline-light rounded-circle py-1 px-2 btn-warn popper" title="Delete this project" data-warning="Do you wish to delete this project? All the data associated with it will be lost forever"><i class="bx bx-trash-alt"></i></a>
                    <a href="/steamProject/<?php echo e($steam->id); ?>/edit" class="btn-outline-light rounded-circle py-1 px-2 popper" title="Edit data"><i class="bx bx-edit-alt"></i></a>
                    <?php if($isMember == true): ?>
                    <a href="/steamProject/<?php echo e($steam->id); ?>/logbook/create" class="btn-outline-light rounded-circle py-1 px-2 popper" title="New log book"><i class="bx bxs-file-plus"></i></a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <div class="text-white text-center">
                    <h3 class="display-5 mb-3"><?php echo e($steam->title); ?></h3>
                    <p><a href="/steamProject/<?php echo e($steam->id); ?>" class="bg-white text-dark fs-9 px-4 py-1 rounded-pill"><?php echo e($steam->steamCategory->name); ?></a></p>
                    <div class="flex-center flex-wrap gap-4 fs-12">
                        <div class="flex-start gap-2"><i class="bx bx-group"></i><?php echo e(count($steam->steamMember)); ?></div>
                        <div class="flex-start gap-2"><i class="bx bx-message"></i><?php echo e(count($steam->comment)); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 p-4 mb-3">
                <p class="text-end text-muted fs-8"><?php echo e(date('d F Y', strtotime($steam->created_at))); ?></p>
                <div class="mb-3">
                    <p class="text-primary fw-500 mb-2">About this project :</p>
                    <p class="fs-9"><?php echo e(($steam->description) ? $steam->description : "No description"); ?></p>
                </div>
                <!-- members start -->
                <div class="mb-3">
                    <p class="text-primary fw-500 mb-2">Members :</p>
                    <div class="d-flex flex-wrap align-items-center gap-3">
                        <?php if(Auth::check() && (Auth::user()->profile->role != 'student' || $isMember == true)): ?>
                        <div class="rounded-circle border border-2 border-primary btn-outline-primary flex-center" style="height:80px;width:80px;" role="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvas-steamMember" aria-controls="offcanvas-steamMember">
                            <i class="bx bx-user-plus fs-14 fw-bold"></i>
                        </div>
                        <?php endif; ?>
                        <div id="container-steamMember-items" class="d-flex flex-wrap align-items-center gap-3">
                        <?php if(count($steam->steamMember) > 0): ?>
                        <?php $i = 1; ?>
                            <?php $__currentLoopData = $steam->steamMember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="steamMember-item-<?php echo e($i); ?>" class="text-center">
                                <img src="<?php echo e(($item->user->picture ? asset('img/profiles/'.$item->user->picture) : asset('img/profiles/user.jpg'))); ?>" id="steamMember-<?php echo e($i); ?>" class="rounded-circle border hover-grow mb-2 popper" style="height:80px" data-title="<?php echo e($item->user->profile->full_name); ?>" data-user_id="<?php echo e($item->user->id); ?>" data-profile_id="<?php echo e($item->user->profile->id); ?>" role="button" onclick="showSteamMember('<?php echo e($i); ?>')">
                                <p class="fs-8 m-0 text-wrap" style="max-width:100px"><?php echo e($item->user->profile->full_name); ?></p>
                            <?php $i++; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <p class="m-0">No one assigned to this project yet</p>
                        <?php endif; ?>
                        </div>
                    </div>
                    <p id="alert-members" class="alert alert-danger d-none"></p>
                </div>
                <!-- members end -->
                <!-- STEAM log start -->
                <div class="mb-3">
                    <p class="text-primary fw-500 mb-3">STEAM log book :</p>
                    <div class="table-container">
                        <table id="table-steamLogBook" class="table table-striped">
                            <thead>
                                <th>Date</th>
                                <th>Title</th>
                            </thead>
                            <tbody>
                                <?php if(count($steam->steamLogBook) > 0): ?>
                                <?php $__currentLoopData = $steam->steamLogBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date('Y/m/d', strtotime($item->created_at))); ?></td>
                                    <td><a href="/steamLogBook/<?php echo e($item->id); ?>" class="hover-primary"><?php echo e($item->title); ?></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- STEAM log end -->
            </div>
        </div>
    </div>
    <!-- container end -->

</section>

<?php echo $__env->make('layouts.partials.modal_steam', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script type="text/javascript">
const lightbox = GLightbox({
    selector: '.glightbox',
});
$(document).ready(function() {
    new DataTable('#table-steamLogBook', {
        pageLength: 50,
        fixedColumns: true,
        ordering: true,
        searching: true,
    });
    $('#link-steam').addClass('active');
    $('#submenu-steam').addClass('show');
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ruang Siswa\resources\views/steam/show.blade.php ENDPATH**/ ?>