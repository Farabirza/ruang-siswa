<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php if(isset($metaTags)): ?>
<meta name="description" content="<?php echo e($metaTags['description']); ?>" />
<meta name="keywords" lan="id" content="website, laravel, app" />
<meta property="og:type" content="laravel app" />
<meta property="og:title" content="<?php echo e($metaTags['title']); ?>" />
<meta property="og:description" content="<?php echo e($metaTags['description']); ?>" />
<!-- <meta property="og:url" content="https://../" /> -->
<meta property="og:site_name" content="Laravel App" />
<meta property="og:image" content="<?php echo e(asset('img/materials/landing.jpg')); ?>" />
<meta property="og:image:type" content="image/jpg" />
<meta property="og:image:width" content="1366" />
<meta property="og:image:height" content="768" />
<meta name="twitter:image" content="<?php echo e(asset('img/materials/landing.jpg')); ?>">
<!-- Favicons -->
<?php if(isset($metaTags['icon'])): ?>
<link href="<?php echo e(asset('/img/logo/'.$metaTags['icon'])); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/'.$metaTags['icon'])); ?>" rel="apple-touch-icon">
<?php else: ?>
<link href="<?php echo e(asset('/img/logo/logo_book_small.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo_book_small.png')); ?>" rel="apple-touch-icon">
<?php endif; ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\Ruang Siswa\resources\views/layouts/partials/metaTags.blade.php ENDPATH**/ ?>